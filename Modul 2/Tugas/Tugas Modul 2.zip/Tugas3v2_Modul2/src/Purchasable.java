public interface Purchasable {
    String getName();

    int getPrice();
}
