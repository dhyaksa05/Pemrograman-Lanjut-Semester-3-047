package Modul2;

public record TicketInfo(String passengerName, String startLocation, String destination, double price, double duration,
                         double speed) {
}